# ARitz Cracker's addon translations.
These are the files used for the default languages for my addons.
## You can help by making pull requests!
### If you're editing an existing file
Great! just submit a pull request
### If you want to submit a new language
I name my translation files with [[language](https://en.wikipedia.org/wiki/List_of_ISO_639-1_codes)]_[[country](https://en.wikipedia.org/wiki/ISO_3166-1_alpha-2)].txt If you wish to submit a new langage, that is how you must name your file.
